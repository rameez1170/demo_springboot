package com.example.demo;


public interface EmployeeRepository extends BaseRepository<Employee, Integer> {

}
